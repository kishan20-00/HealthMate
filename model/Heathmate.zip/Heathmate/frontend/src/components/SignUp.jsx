import React, { useState } from 'react';
import loginCoupleImage from '../assets/fitcouple2.png';
import { NavLink } from 'react-router-dom';
import logoImg from '../assets/logo.png';
import { useNavigate } from 'react-router-dom';

const SignUp = ({ setCurrentPage }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    height: '',
    weight: '',
    activityLevel: '',
    sleepHours: '',
    hydration: '',
    stress: '',
    smoking: ''
  });

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleGoogleLogin = () => {
    window.open('https://www.google.com', '_blank');
  };

  const handleFacebookLogin = () => {
    window.open('https://www.facebook.com', '_blank');
  };
  const handleHomeNavigation = () => {
    navigate('/');
  };

  return (
    <div className="signup-container">
      <div className="signup-left">
        <div className='signup-top-left-bar'>
          <div className="logo-small">
            <img className="logo-image-small" src={logoImg} onClick={handleHomeNavigation}/>
          </div>
          <div className="motivational-text">
            <h3>Your <span className="highlight">future</span> is created by what you do today, not <span className="highlight">tomorrow</span>.</h3>
          </div>
      </div>
      <div className="signup-fitness-img-container">
        <img className="signup-fitness-img" src={loginCoupleImage}/>
      </div>
      </div>


      <div className="signup-right">
        <div className="signup-form">
          <h2>Sign Up</h2>

          <div className="form-row">
            <input
              type="text"
              name="name"
              placeholder="Name"
              value={formData.name}
              onChange={handleInputChange}
              className="form-input"
            />
          </div>

          <div className="form-row two-cols">
            <input
              type="number"
              name="age"
              placeholder="Age"
              value={formData.age}
              onChange={handleInputChange}
              className="form-input half-width"
            />
            <select
              name="gender"
              value={formData.gender}
              onChange={handleInputChange}
              className="form-input half-width"
            >
              <option value="">Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div className="form-row two-cols">
            <input
              type="text"
              name="height"
              placeholder="Height"
              value={formData.height}
              onChange={handleInputChange}
              className="form-input half-width"
            />
            <input
              type="text"
              name="weight"
              placeholder="Weight"
              value={formData.weight}
              onChange={handleInputChange}
              className="form-input half-width"
            />
          </div>

          <select
            name="activityLevel"
            value={formData.activityLevel}
            onChange={handleInputChange}
            className="form-input"
          >
            <option value="">Activity Level</option>
            <option value="sedentary">Sedentary</option>
            <option value="light">Light</option>
            <option value="moderate">Moderate</option>
            <option value="active">Active</option>
            <option value="very-active">Very Active</option>
          </select>

          <select
            name="sleepHours"
            value={formData.sleepHours}
            onChange={handleInputChange}
            className="form-input"
          >
            <option value="">Sleep Hours</option>
            <option value="less-than-6">Less than 6 hours</option>
            <option value="6-7">6-7 hours</option>
            <option value="7-8">7-8 hours</option>
            <option value="8-9">8-9 hours</option>
            <option value="more-than-9">More than 9 hours</option>
          </select>

          <select
            name="hydration"
            value={formData.hydration}
            onChange={handleInputChange}
            className="form-input"
          >
            <option value="">Hydration</option>
            <option value="poor">Poor (Less than 4 glasses)</option>
            <option value="fair">Fair (4-6 glasses)</option>
            <option value="good">Good (6-8 glasses)</option>
            <option value="excellent">Excellent (8+ glasses)</option>
          </select>

          <select
            name="stress"
            value={formData.stress}
            onChange={handleInputChange}
            className="form-input"
          >
            <option value="">Stress</option>
            <option value="low">Low</option>
            <option value="moderate">Moderate</option>
            <option value="high">High</option>
            <option value="very-high">Very High</option>
          </select>

          <select
            name="smoking"
            value={formData.smoking}
            onChange={handleInputChange}
            className="form-input"
          >
            <option value="">Smoking</option>
            <option value="never">Never</option>
            <option value="occasionally">Occasionally</option>
            <option value="regularly">Regularly</option>
            <option value="heavily">Heavily</option>
          </select>

          <button className="signup-submit-btn">Sign Up</button>

          <p className="login-link">
            Already have an account?
            <a href="http://localhost:5173/login" onClick={() => setCurrentPage('login')}>Log In</a>
          </p>

          <div className="divider">or</div>

          <div className="social-login">
            <button className="google-btn" onClick={handleGoogleLogin}>
              <span className="google-icon">G</span>
              Google
            </button>
            <button className="facebook-btn" onClick={handleFacebookLogin}>
              <span className="facebook-icon">f</span>
              Facebook
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;