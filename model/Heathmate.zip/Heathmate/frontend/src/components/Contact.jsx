import React from 'react';

const Contact = ({ setCurrentPage }) => {
  return (
    <div className="page-container">
      <nav className="navbar">
        <div className="nav-brand">
          <span className="brand-text">HealthMate</span>
        </div>
        <div className="nav-links">
          <a href="#" onClick={() => setCurrentPage('home')}>Home</a>
          <a href="#" onClick={() => setCurrentPage('about')}>About</a>
          <a href="#" onClick={() => setCurrentPage('contact')}>Contact</a>
        </div>
      </nav>
      
      <div className="page-content">
        <h1>Contact Us</h1>
        <p>Get in touch with the HealthMate team for support and inquiries.</p>
      </div>
    </div>
  );
};

export default Contact;