import React from 'react';

const About = ({ setCurrentPage }) => {
  return (
    <div className="page-container">
      <nav className="navbar">
        <div className="nav-brand">
          <span className="brand-text">HealthMate</span>
        </div>
        <div className="nav-links">
          <a href="#" onClick={() => setCurrentPage('home')}>Home</a>
          <a href="#" onClick={() => setCurrentPage('about')}>About</a>
          <a href="#" onClick={() => setCurrentPage('contact')}>Contact</a>
        </div>
      </nav>
      
      <div className="page-content">
        <h1>About HealthMate</h1>
        <p>Your AI-driven health and fitness companion designed to help you achieve your wellness goals.</p>
      </div>
    </div>
  );
};

export default About;
