import React from "react";

const Navbar = () => {
  return (
    <nav className="flex justify-end p-4 gap-6 font-medium">
      <a href="#">Home</a>
      <a href="#">About</a>
      <a href="#">Contact</a>
    </nav>
  );
};

export default Navbar;
