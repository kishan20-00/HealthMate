import React from 'react';
import { useNavigate } from 'react-router-dom';
import logoImg from '../assets/logo.png';

const Home = () => {
  const navigate = useNavigate();

  const handleLoginClick = () => {
    navigate('/login');
  };

  const handleSignupClick = () => {
    navigate('/signup');
  };

  return (
    <div className="home-container">
      <nav className="navbar">
        <div className="nav-brand">
        </div>
        <div className="nav-links">
          <a href="#" onClick={() => navigate('/')}>Home</a>
          <a href="#" onClick={() => navigate('/about')}>About</a>
          <a href="#" onClick={() => navigate('/contact')}>Contact</a>
        </div>
      </nav>

      <div className="hero-section">
        <div className="geometric-shapes">
          <div className="triangle triangle-1"></div>
          <div className="triangle triangle-2"></div>
          <div className="triangle triangle-3"></div>
          <div className="triangle triangle-4"></div>
        </div>

        <div className="hero-content">
          <div className="logo">
            <img className="logo-image" src={logoImg}/>
          </div>
          <p className="subtitle">Your AI - driven health & fitness companion</p>
          
          <div className="auth-buttons">
            <button 
              className="login-btn"
              onClick={handleLoginClick}
            >
              Login
            </button>
            <button 
              className="signup-btn"
              onClick={handleSignupClick}
            >
              Sign Up
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;