import React from "react";
import "./dashboard.css";

const Dashboard = () => {
  return (
    <div className="container">
      {/* Sidebar */}
      <div className="sidebar">
        <div className="logo">
          <div className="logo-icon">♥</div>
          <div className="logo-text">HealthMate</div>
        </div>

        <div className="menu-label">Menu</div>

        <ul className="nav-menu">
          <li className="nav-item">
            <a href="#" className="nav-link active">
              <span>📊</span>
              Dashboard
            </a>
          </li>
          <li className="nav-item">
            <a href="#" className="nav-link">
              <span>🔔</span>
              Schedule Reminder
            </a>
          </li>
          <li className="nav-item">
            <a href="#" className="nav-link">
              <span>📈</span>
              Reports
            </a>
          </li>
          <li className="nav-item">
            <a href="#" className="nav-link">
              <span>🔔</span>
              Notifications
            </a>
          </li>
          <li className="nav-item">
            <a href="#" className="nav-link">
              <span>⚙️</span>
              Settings
            </a>
          </li>
        </ul>

        <div className="user-profile">
          <div className="user-avatar">S</div>
          <div className="user-info">
            <div className="user-name">Shenal Perera</div>
            <div className="user-email">shenaloka8@gmail.com</div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        <div className="header">
          <h1 className="welcome-title">Welcome back Shenal!</h1>
          <div className="search-date">
            <input type="text" className="search-box" placeholder="Search" />
            <select className="date-selector">
              <option>Tue, 24 Sep 2025</option>
            </select>
          </div>
        </div>

        {/* Status Card */}
        <div className="status-card">
          <div className="status-text">✓ BMI: Normal, Active lifestyle</div>
          <div className="status-subtext">
            Don't skip breakfast; it kick-starts your metabolism.
          </div>
        </div>

        {/* Metrics Row */}
        <div className="metrics-row">
          <div className="metric-card steps">
            <div className="metric-header">
              <span className="metric-title">Steps</span>
              <span className="metric-percentage">90%</span>
            </div>
            <div className="metric-value">5000</div>
          </div>

          <div className="metric-card sleep">
            <div className="metric-header">
              <span className="metric-title">Sleep</span>
              <span className="metric-percentage">85%</span>
            </div>
            <div className="metric-value">
              6.5<span className="metric-unit">h</span>
            </div>
          </div>

          <div className="metric-card hydration">
            <div className="metric-header">
              <span className="metric-title">Hydration</span>
              <span className="metric-percentage">68%</span>
            </div>
            <div className="metric-value">
              2<span className="metric-unit">L</span>
            </div>
          </div>
        </div>

        {/* Progress Section */}
        <div className="progress-section">
          <div className="progress-header">
            <h2 className="progress-title">Goal Progress</h2>
            <select className="progress-select">
              <option>Weekly</option>
            </select>
          </div>

          <div className="chart-container">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, i) => (
              <div className="chart-bar" key={i}>
                <div className="bar-group">
                  <div
                    className="bar workout-bar"
                    style={{ height: `${60 + i * 5}px` }}
                  ></div>
                  <div
                    className="bar calories-bar"
                    style={{ height: `${40 + i * 5}px` }}
                  ></div>
                  <div
                    className="bar steps-bar"
                    style={{ height: `${50 + i * 5}px` }}
                  ></div>
                </div>
                <div className="day-label">{day}</div>
              </div>
            ))}
          </div>

          <div className="chart-legend">
            <div className="legend-item">
              <div className="legend-dot workout-bar"></div>
              Workout
            </div>
            <div className="legend-item">
              <div className="legend-dot calories-bar"></div>
              Calories
            </div>
            <div className="legend-item">
              <div className="legend-dot steps-bar"></div>
              Steps
            </div>
          </div>
        </div>

        {/* Recommendations */}
        <div className="recommendations">
          <div className="recommendations-header">
            <h2 className="recommendations-title">
              Today's Quick Recommendation
            </h2>
            <a href="#" className="see-all">
              See All ↗
            </a>
          </div>
          <div className="recommendations-subtitle">
            Consuming fruit juices keeps up the hydration level.
          </div>

          <div className="recommendation-cards">
            <div className="recommendation-card">
              <div className="recommendation-icon exercise-icon">🚶</div>
              <div className="recommendation-title">Exercise</div>
              <div className="recommendation-subtitle">Walk 30 mins</div>
            </div>
            <div className="recommendation-card">
              <div className="recommendation-icon nutrition-icon">🍽️</div>
              <div className="recommendation-title">Nutrition</div>
              <div className="recommendation-subtitle">Balanced Meal</div>
            </div>
            <div className="recommendation-card">
              <div className="recommendation-icon lifestyle-icon">🧘</div>
              <div className="recommendation-title">Lifestyle</div>
              <div className="recommendation-subtitle">Drink more water</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Sidebar */}
      <div className="right-sidebar">
        <div className="widget calories-widget">
          <div className="widget-label">🔥 Calories</div>
          <div className="widget-subtitle">Today</div>
          <div className="calories-number">Under</div>
        </div>

        <div className="widget heart-rate-widget">
          <div className="widget-label">❤️ Heart Rate</div>
          <div className="heart-rate-chart">
            <div className="heart-rate-line"></div>
          </div>
          <div className="heart-rate-value">
            110 <span className="bpm-unit">Bpm</span>
          </div>
        </div>

        <div className="widget goals-widget">
          <h3>Today's Goal</h3>
          <div className="goal-item">
            <div className="goal-label">Steps Goal:</div>
            <div className="goal-detail">Walk 8,000 steps today</div>
          </div>
          <div className="goal-item">
            <div className="goal-label">Hydration Goal:</div>
            <div className="goal-detail">Drink 2.5 liters of water</div>
          </div>
          <div className="goal-item">
            <div className="goal-label">Sleep Goal:</div>
            <div className="goal-detail">Get at least 7 hours of sleep</div>
          </div>
          <div className="goal-item">
            <div className="goal-label">Nutrition Goal:</div>
            <div className="goal-detail">Eat 3 balanced meals today</div>
          </div>
        </div>

        <div className="widget activity-log">
          <h3>Activity Log</h3>
          <div className="activity-item">
            <div className="activity-dot"></div>
            <div className="activity-details">
              <div className="activity-amount">250 ml</div>
              <div className="activity-time">8:00 am</div>
            </div>
          </div>
          <div className="activity-item">
            <div className="activity-dot"></div>
            <div className="activity-details">
              <div className="activity-amount">200 ml</div>
              <div className="activity-time">6:30 am</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
