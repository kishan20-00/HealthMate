import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import logoImg from '../assets/logo.png';
import coupleImg from '../assets/fitness-couple-home.png';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleGoogleLogin = () => {
    window.open('https://www.google.com', '_blank');
  };

  const handleFacebookLogin = () => {
    window.open('https://www.facebook.com', '_blank');
  };

  const handleSignupNavigation = () => {
    navigate('/signup');
  };
  const handleHomeNavigation = () => {
    navigate('/');
  };
  const handleDashboardNavigation = () => {
    navigate('/dashboard');
  };

  return (
    <div className="login-container">
      <div className="login-left">
        <div className="logo-small">
          <img className="logo-image-small" src={logoImg} onClick={handleHomeNavigation}/>
        </div>

        <div className="login-form" onClick={handleDashboardNavigation}>
          <h2>Log In</h2>
          
          <div className="form-group">
            <input 
              type="email" 
              placeholder="Your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="form-input"
            />
          </div>

          <div className="form-group">
            <input 
              type="password" 
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="form-input"
            />
          </div>

          <button className="login-submit-btn">Log In</button>
          
          <a href="#" className="forgot-password">Forgot password?</a>
          
          <div className="divider">or</div>
          
          <div className="social-login">
            <button className="google-btn" onClick={handleGoogleLogin}>
              <span className="google-icon">G</span>
              Google
            </button>
            <button className="facebook-btn" onClick={handleFacebookLogin}>
              <span className="facebook-icon">f</span>
              Facebook
            </button>
          </div>
          
          <p className="signup-link">
            Don't have an account? 
            <a href="#" onClick={handleSignupNavigation}>Sign Up</a>
          </p>
        </div>
      </div>

      <div className="login-right">
        <div className="motivational-text">
          <h3>Small <span className="highlight">changes</span> every day lead to big results.</h3>
        </div>
        <div className="login-fitness-img-container">
          <img className="login-fitness-img" src={coupleImg}/>
        </div>
      </div>
    </div>
  );
};

export default Login;