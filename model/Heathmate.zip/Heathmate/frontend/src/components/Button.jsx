import React from "react";

const Button = ({ children, type = "primary", onClick }) => {
  const baseClasses = "px-6 py-2 rounded font-medium";
  const primaryClasses = "bg-green-400 text-black hover:bg-green-500";
  const secondaryClasses = "border border-gray-400 text-black hover:bg-gray-100";

  return (
    <button
      className={`${baseClasses} ${type === "primary" ? primaryClasses : secondaryClasses}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
};

export default Button;
